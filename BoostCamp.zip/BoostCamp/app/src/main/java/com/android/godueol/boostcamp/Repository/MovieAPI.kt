package com.android.godueol.boostcamp.Repository

import io.reactivex.Observable
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.http.GET
import retrofit2.http.Headers


class MovieAPI() {

    val mRetrofit: Retrofit
    val mAPI: API
    val HOST = "https://openapi.naver.com/v1/"

    init {
        mRetrofit = Retrofit.Builder()
            .baseUrl(HOST)
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .build()
        mAPI = mRetrofit.create(API::class.java)
    }
//wEPUsnDZSbPUaQ3asew0
    //ctaeIzO3TL
    companion object {
        @Volatile
        private var mInstance: MovieAPI? = null
        //SingleTon
        val instance: MovieAPI
            get() = synchronized(MovieAPI::class.java) {
                if (mInstance == null) {
                    mInstance =
                            MovieAPI()
                }
                return mInstance as MovieAPI
            }
    }

    interface API {
        @GET("search/movie.json")
        @Headers("X-Naver-Client-Id:wEPUsnDZSbPUaQ3asew0","X-Naver-Client-Secret:ctaeIzO3TL")
        fun getMovieList(): Observable<Response<RequestBody>>
    }
}
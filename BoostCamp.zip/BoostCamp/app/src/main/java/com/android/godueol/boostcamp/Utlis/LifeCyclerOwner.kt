package com.android.godueol.boostcamp.Utlis



enum class Event{
    OnCreate,
    OnStart,
    OnResume,
    OnPause,
    OnStop,
    OnDestroy
}
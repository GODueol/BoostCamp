package com.android.godueol.boostcamp

import android.widget.Button
import androidx.lifecycle.ViewModel
import com.android.godueol.boostcamp.Repository.MovieAPI
import com.android.godueol.boostcamp.Utlis.Event
import com.android.godueol.boostcamp.Utlis.RxBinder
import com.android.godueol.boostcamp.Utlis.threadIoToMain

class MovieSearchViewModel(val rxBinder: RxBinder) : ViewModel() {

    fun onSearch(v: Button) {
        rxBinder.bind(Event.OnDestroy) {
            MovieAPI.instance.mAPI
                .getMovieList()
                .compose(threadIoToMain())
                .filter {
                    it.isSuccessful
                }
                .map {
                    it.body().toString()
                }
                .subscribe(
                    {
                        System.out.print(it)
                    },{
                        System.out.println(it.message)
                    }
                )
        }
    }
}
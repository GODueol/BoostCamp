package com.android.godueol.boostcamp.Utlis

import io.reactivex.disposables.CompositeDisposable
import io.reactivex.disposables.Disposable
import java.util.*

class RxBinder {

    val taskMap = HashMap<Event, CompositeDisposable>()

    fun apply(event: Event) {
        taskMap[event]?.clear()
    }

    fun bind(event: Event, task: () -> Disposable) {
        taskMap[event]?.add(task())
    }

}